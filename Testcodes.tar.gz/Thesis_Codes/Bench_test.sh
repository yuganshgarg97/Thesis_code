./setup.sh
clear
echo "Test Started "
sleep 60
echo " Welcome to "> Data.docx
uname -a >> Data.docx
whoami >> Data.docx
uptime >> Data.docx
lscpu  >> Data.docx
free -h >> Data.docx
du -h >>Data.docx
free -h >> Data.docx
sleep 20
speedtest >> Data.docx
sleep 20
echo "Process-Name,Time-Taken,Avg-CPU-usage,Agv-Memory-usage,Avg-Swap-usage"> Matrix.csv
mkdir Read_Write_stats
sar -u 1 >> Read_Write_stats/cpu_data.csv |sar -r 1 >> Read_Write_stats/memory_data.csv | sar -S 1 >> Read_Write_stats/swap_data.csv | python Read-Write_test.py>> Data.docx
echo " Read/Write Test Completed "
sleep 20
cp cpu_data_report.py memory_data.py swap_data.py processed-list.py Read_Write_stats/
cd Read_Write_stats/
python cpu_data_report.py >> ../Data.docx
python memory_data.py >> ../Data.docx
python swap_data.py >> ../Data.docx
python processed-list.py >> ../Data.docx
echo " Data Processed"
cd ..
sleep 20
mkdir copy_test_stats
sar -u 1 >> copy_test_stats/cpu_data.csv |sar -r 1 >> copy_test_stats/memory_data.csv | sar -S 1 >> copy_test_stats/swap_data.csv | python Copy_Data.py >> Data.docx
echo " Copy Test Completed"
rm -rf /var/Bench_Test_Images
sleep 20
cp cpu_data_report.py memory_data.py swap_data.py processed-list.py copy_test_stats/
cd copy_test_stats/
python cpu_data_report.py >> ../Data.docx
python memory_data.py >> ../Data.docx
python swap_data.py >> ../Data.docx
python processed-list.py
echo " Data Processed"
cd ..
sleep 20
mkdir Compression_stats
sar -u 1 >> Compression_stats/cpu_data.csv |sar -r 1 >>Compression_stats/memory_data.csv | sar -S 1 >>Compression_stats/swap_data.csv | python Compression.py>> Data.docx
echo " Compresion Test  Completed"
rm -rf Bench_Test_Images/
sleep 20
cp cpu_data_report.py memory_data.py swap_data.py processed-list.py Compression_stats/
cd Compression_stats/
python cpu_data_report.py >> ../Data.docx
python memory_data.py >> ../Data.docx
python swap_data.py >> ../Data.docx
python processed-list.py
echo " Data Processed"
cd ..
sleep 20
mkdir Extraction_stats
sar -u 1 >> Extraction_stats/cpu_data.csv |sar -r 1 >> Extraction_stats/memory_data.csv | sar -S 1 >> Extraction_stats/swap_data.csv | python Extraction.py >> Data.docx
echo " Extraction Test Completed"
rm -rf Bench_image.tar.gx
rm -rf Extracted/
sleep 20
cp cpu_data_report.py memory_data.py swap_data.py processed-list.py Extraction_stats/
cd Extraction_stats/
python cpu_data_report.py >> ../Data.docx
python memory_data.py >> ../Data.docx
python swap_data.py >> ../Data.docx
python processed-list.py
echo " Data Processed"
cd ..
sleep 20
mkdir Download_stats
sar -u 1 >> Download_stats/cpu_data.csv |sar -r 1 >> Download_stats/memory_data.csv | sar -S 1 >> Download_stats/swap_data.csv | python  Download_test.py>>Data.docx
echo " Download test completed"
sleep 20
mkdir Hashing_stats
sar -u 1 >> Hashing_stats/cpu_data.csv |sar -r 1 >>Hashing_stats/memory_data.csv | sar -S 1 >> Hashing_stats/swap_data.csv | python Hashing.py >> Data.docx
echo " Hashing Completed"
sleep 20
cp cpu_data_report.py memory_data.py swap_data.py processed-list.py Hashing_stats/
cd Hashing_stats/
python cpu_data_report.py >> ../Data.docx
python memory_data.py >> ../Data.docx
python swap_data.py >> ../Data.docx
python processed-list.py
echo " Data Processed"
cd ..
sleep 20
mkdir Encryption_stats
sar -u 1 >> Encryption_stats/cpu_data.csv |sar -r 1 >> Encryption_stats/memory_data.csv | sar -S 1 >> Encryption_stats/swap_data.csv | python AES_encryption.py>> Data.docx
echo " Encryption Completed"
sleep 20
cp cpu_data_report.py memory_data.py swap_data.py processed-list.py Encryption_stats/
cd Encryption_stats/
python cpu_data_report.py >> ../Data.docx
python memory_data.py >> ../Data.docx
python swap_data.py >> ../Data.docx
python processed-list.py
echo " Data Processed"
cd ..
sleep 20
mkdir Decryption_stats
sar -u 1 >> Decryption_stats/cpu_data.csv |sar -r 1 >> Decryption_stats/memory_data.csv | sar -S 1 >> Decryption_stats/swap_data.csv | python AES_decryption.py>> Data.docx
echo " Decryption Completed"
cp cpu_data_report.py memory_data.py swap_data.py processed-list.py Decryption_stats/
cd Decryption_stats/
python cpu_data_report.py >> ../Data.docx
python memory_data.py >> ../Data.docx
python swap_data.py >> ../Data.docx
python processed-list.py
echo " Data Processed"
cd ..
sleep 20
rm -rf encrypted ubuntu.iso
mv Test_image.iso ../
sleep 20
mkdir Sorting_stats
sar -u 1 >> Sorting_stats/cpu_data.csv |sar -r 1 >> Sorting_stats/memory_data.csv | sar -S 1 >> Sorting_stats/swap_data.csv | python mergesort.py>> Data.docx
echo " Merge Sort Completed"
sleep 20
cp cpu_data_report.py memory_data.py swap_data.py processed-list.py Sorting_stats/
cd Sorting_stats/
python cpu_data_report.py >> ../Data.docx
python memory_data.py >> ../Data.docx
python swap_data.py >> ../Data.docx
python processed-list.py
echo " Data Processed"
cd ..
sleep 20
mkdir Random_Algorithm_stats
sar -u 1 >> Random_Algorithm_stats/cpu_data.csv |sar -r 1 >> Random_Algorithm_stats/memory_data.csv | sar -S 1 >> Random_Algorithm_stats/swap_data.csv | python random_test.py >>  Data.docx
echo " Random Algorithm test completed"
sleep 20
cp cpu_data_report.py memory_data.py swap_data.py processed-list.py Random_Algorithm_stats/
cd Random_Algorithm_stats/
python cpu_data_report.py >> ../Data.docx
python memory_data.py >> ../Data.docx
python swap_data.py >> ../Data.docx
python processed-list.py
echo " Data Processed"
cd ..
sleep 20
mkdir Integer_Test_stats
sar -u 1 >> Integer_Test_stats/cpu_data.csv |sar -r 1 >> Integer_Test_stats/memory_data.csv | sar -S 1 >> Integer_Test_stats/swap_data.csv | python Integer_test.py >> Data.docx
echo "Integer Test Completed"
sleep 20
cp cpu_data_report.py memory_data.py swap_data.py processed-list.py Integer_Test_stats/
cd Integer_Test_stats/
python cpu_data_report.py >> ../Data.docx
python memory_data.py >> ../Data.docx
python swap_data.py >> ../Data.docx
python processed-list.py
echo " Data Processed"
cd ..
sleep 20
timeout 100 bash float_test.sh
sleep 20
./Complete.sh

