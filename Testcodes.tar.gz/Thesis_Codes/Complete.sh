echo " All Test Completed Successfully"
echo " Finalizing the Process"
tar -cvf results.tar.gz *_stats/ *.docx *.csv
python python_rename.py
mv *.tar.gz ../../
cd ..
rm -rf Thesis_Codes/
pkill sar
exit
exit
