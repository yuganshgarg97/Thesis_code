import time
Start = time.time()
print("The Process to Test  Read/Write operations began at ",time.ctime())
s = 0
for i in range(1,20):
    for j in range(1,1000000):
        s += j/10**i +(j**2)/10**i + j**3/(10**i)
print(s)
End = time.time()
print("The Process to test Read/Write operations Ended at ",time.ctime())
print("Time taken to Read/Write  = ",End-Start,"Seconds")

